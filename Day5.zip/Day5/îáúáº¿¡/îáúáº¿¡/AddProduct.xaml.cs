﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Магазин
{
    /// <summary>
    /// Логика взаимодействия для AddProduct.xaml
    /// </summary>
    public partial class AddProduct : Window
    {
        
        public AddProduct()
        {
            InitializeComponent();
            cbCategory.ItemsSource = App.trade.Categories.
                Select(c=>c.CategoryName).ToList();
            cbManufacturer.ItemsSource = App.trade.Manufactureds.
                Select(c=>c.ManufacturedName).ToList();
            cbSupplier.ItemsSource = App.trade.Suppliers.
                Select(c=>c.SuppliersName).ToList();
            cbUnitOfMeasurement.ItemsSource = App.trade.Units.
                Select(c=>c.UnitName).ToList();
            
        }

        private void AddProduct_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (tbArticle.Text == "" | tbName.Text == "" | 
                    tbDescription.Text == "" | cbCategory.Text == "" 
                    | cbManufacturer.Text == ""
                    | tbCost.Text == "" | tbDescription.Text == ""
                    | tbQuantityInStock.Text == "" | 
                    tbMaxDiscount.Text == "")
                {
                    MessageBox.Show("Заполните все поля!");
                }
                else
                {
                    int categoryID = App.trade.Categories.
                        Where(x => x.CategoryName == cbCategory.Text).
                        Select(x => x.idCategory).FirstOrDefault();
                    int manufacturerID = App.trade.Manufactureds.
                        Where(x => x.ManufacturedName == cbManufacturer.Text).
                        Select(x => x.idManufactured).FirstOrDefault();
                    int unitOfMeasurrementID = App.trade.Units.
                        Where(x => x.UnitName == cbUnitOfMeasurement.Text).
                        Select(x => x.idUnit).FirstOrDefault();
                    int suppliersID = App.trade.Suppliers.
                        Where(x => x.SuppliersName == cbSupplier.Text).
                        Select(x => x.idSuppliers).FirstOrDefault();
                    DB.Product product = new DB.Product()
                    {
                        ProductArticleNumber = tbArticle.Text,
                        ProductName = tbName.Text,
                        Description = tbDescription.Text,
                        idCategory = categoryID,
                        idManufactured = manufacturerID,
                        Price = Convert.ToDecimal(tbCost.Text),
                        CurrentDiscount = Convert.ToInt32(tbDiscount.Text),
                        QuantityStock = Convert.ToInt32(tbQuantityInStock.Text),
                        MaximumDiscountSize = Convert.ToInt32(tbMaxDiscount.Text),
                        idSuppliers = suppliersID
                    };
                    App.trade.Products.Add(product);
                    App.trade.SaveChanges();
                    MessageBox.Show("Данные успешно добавлены!");
                    WinAdmin administrator = new WinAdmin();
                    administrator.Show();
                    this.Close();
                }

            }
            catch
            {
                MessageBox.Show("Одна из строк имела неверный формат!");
            }
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            WinAdmin administrator = new WinAdmin();
            administrator.Show();
            this.Close();
        }
    }
}
